﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Main
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Main))
        Me.C1 = New System.Windows.Forms.ComboBox()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.TB12 = New System.Windows.Forms.TextBox()
        Me.Label33 = New System.Windows.Forms.Label()
        Me.Button9 = New System.Windows.Forms.Button()
        Me.Button7 = New System.Windows.Forms.Button()
        Me.Button5 = New System.Windows.Forms.Button()
        Me.Button8 = New System.Windows.Forms.Button()
        Me.Button6 = New System.Windows.Forms.Button()
        Me.Button4 = New System.Windows.Forms.Button()
        Me.Label27 = New System.Windows.Forms.Label()
        Me.Label32 = New System.Windows.Forms.Label()
        Me.Label31 = New System.Windows.Forms.Label()
        Me.LST7 = New System.Windows.Forms.ListBox()
        Me.Label30 = New System.Windows.Forms.Label()
        Me.LST6 = New System.Windows.Forms.ListBox()
        Me.Label29 = New System.Windows.Forms.Label()
        Me.LST5 = New System.Windows.Forms.ListBox()
        Me.Label28 = New System.Windows.Forms.Label()
        Me.LST4 = New System.Windows.Forms.ListBox()
        Me.Label26 = New System.Windows.Forms.Label()
        Me.LST3 = New System.Windows.Forms.ListBox()
        Me.Label25 = New System.Windows.Forms.Label()
        Me.LST2 = New System.Windows.Forms.ListBox()
        Me.Label22 = New System.Windows.Forms.Label()
        Me.LST1 = New System.Windows.Forms.ListBox()
        Me.Button3 = New System.Windows.Forms.Button()
        Me.L2 = New System.Windows.Forms.Label()
        Me.L1 = New System.Windows.Forms.Label()
        Me.TB11 = New System.Windows.Forms.TextBox()
        Me.Label17 = New System.Windows.Forms.Label()
        Me.TB10 = New System.Windows.Forms.TextBox()
        Me.Label18 = New System.Windows.Forms.Label()
        Me.TB9 = New System.Windows.Forms.TextBox()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.L4 = New System.Windows.Forms.Label()
        Me.L3 = New System.Windows.Forms.Label()
        Me.CB2 = New System.Windows.Forms.CheckBox()
        Me.CB1 = New System.Windows.Forms.CheckBox()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.TB7 = New System.Windows.Forms.TextBox()
        Me.Label20 = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.TB6 = New System.Windows.Forms.TextBox()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.TB5 = New System.Windows.Forms.TextBox()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.TB4 = New System.Windows.Forms.TextBox()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.TB3 = New System.Windows.Forms.TextBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.TB2 = New System.Windows.Forms.TextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.TB1 = New System.Windows.Forms.TextBox()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.Label23 = New System.Windows.Forms.Label()
        Me.Label24 = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'C1
        '
        Me.C1.BackColor = System.Drawing.Color.FromArgb(CType(CType(27, Byte), Integer), CType(CType(27, Byte), Integer), CType(CType(27, Byte), Integer))
        Me.C1.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.C1.Font = New System.Drawing.Font("Courier New", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.C1.ForeColor = System.Drawing.Color.White
        Me.C1.FormattingEnabled = True
        Me.C1.Items.AddRange(New Object() {"RED", "GREEN", "BLUE", "ORANGE", "PINK", "YELLOW", "WHITE", "NONE"})
        Me.C1.Location = New System.Drawing.Point(255, 733)
        Me.C1.Name = "C1"
        Me.C1.Size = New System.Drawing.Size(122, 35)
        Me.C1.TabIndex = 144
        '
        'Label13
        '
        Me.Label13.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Label13.Font = New System.Drawing.Font("Courier New", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label13.ForeColor = System.Drawing.Color.White
        Me.Label13.Location = New System.Drawing.Point(14, 733)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(347, 35)
        Me.Label13.TabIndex = 143
        Me.Label13.Text = "SEPARATOR COLOURS"
        Me.Label13.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'TB12
        '
        Me.TB12.BackColor = System.Drawing.Color.FromArgb(CType(CType(25, Byte), Integer), CType(CType(25, Byte), Integer), CType(CType(25, Byte), Integer))
        Me.TB12.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.TB12.Font = New System.Drawing.Font("Courier New", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TB12.ForeColor = System.Drawing.Color.White
        Me.TB12.Location = New System.Drawing.Point(246, 480)
        Me.TB12.Name = "TB12"
        Me.TB12.Size = New System.Drawing.Size(99, 29)
        Me.TB12.TabIndex = 142
        '
        'Label33
        '
        Me.Label33.Font = New System.Drawing.Font("Courier New", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label33.ForeColor = System.Drawing.Color.White
        Me.Label33.Location = New System.Drawing.Point(14, 480)
        Me.Label33.Name = "Label33"
        Me.Label33.Size = New System.Drawing.Size(186, 28)
        Me.Label33.TabIndex = 141
        Me.Label33.Text = "CUSTOM CLIMB"
        Me.Label33.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Button9
        '
        Me.Button9.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button9.Font = New System.Drawing.Font("Courier New", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button9.ForeColor = System.Drawing.Color.White
        Me.Button9.Location = New System.Drawing.Point(1397, 733)
        Me.Button9.Name = "Button9"
        Me.Button9.Size = New System.Drawing.Size(289, 35)
        Me.Button9.TabIndex = 140
        Me.Button9.Text = "QUICK GUIDE"
        Me.Button9.UseVisualStyleBackColor = True
        '
        'Button7
        '
        Me.Button7.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button7.Font = New System.Drawing.Font("Courier New", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button7.ForeColor = System.Drawing.Color.White
        Me.Button7.Location = New System.Drawing.Point(383, 733)
        Me.Button7.Name = "Button7"
        Me.Button7.Size = New System.Drawing.Size(1008, 35)
        Me.Button7.TabIndex = 139
        Me.Button7.Text = "V3.0.6"
        Me.Button7.UseVisualStyleBackColor = True
        '
        'Button5
        '
        Me.Button5.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button5.Font = New System.Drawing.Font("Courier New", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button5.ForeColor = System.Drawing.Color.White
        Me.Button5.Location = New System.Drawing.Point(13, 677)
        Me.Button5.Name = "Button5"
        Me.Button5.Size = New System.Drawing.Size(836, 50)
        Me.Button5.TabIndex = 138
        Me.Button5.Text = "COPY PREVIOUS PDCS"
        Me.Button5.UseVisualStyleBackColor = True
        '
        'Button8
        '
        Me.Button8.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button8.Font = New System.Drawing.Font("Courier New", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button8.ForeColor = System.Drawing.Color.White
        Me.Button8.Location = New System.Drawing.Point(1271, 621)
        Me.Button8.Name = "Button8"
        Me.Button8.Size = New System.Drawing.Size(415, 50)
        Me.Button8.TabIndex = 137
        Me.Button8.Text = "COPY LAST SQUAWK"
        Me.Button8.UseVisualStyleBackColor = True
        '
        'Button6
        '
        Me.Button6.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button6.Font = New System.Drawing.Font("Courier New", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button6.ForeColor = System.Drawing.Color.White
        Me.Button6.Location = New System.Drawing.Point(855, 621)
        Me.Button6.Name = "Button6"
        Me.Button6.Size = New System.Drawing.Size(410, 50)
        Me.Button6.TabIndex = 136
        Me.Button6.Text = "COPY LAST VIA"
        Me.Button6.UseVisualStyleBackColor = True
        '
        'Button4
        '
        Me.Button4.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button4.Font = New System.Drawing.Font("Courier New", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button4.ForeColor = System.Drawing.Color.White
        Me.Button4.Location = New System.Drawing.Point(13, 621)
        Me.Button4.Name = "Button4"
        Me.Button4.Size = New System.Drawing.Size(836, 50)
        Me.Button4.TabIndex = 135
        Me.Button4.Text = "COPY LAST PDC"
        Me.Button4.UseVisualStyleBackColor = True
        '
        'Label27
        '
        Me.Label27.Font = New System.Drawing.Font("Courier New", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label27.ForeColor = System.Drawing.Color.White
        Me.Label27.Location = New System.Drawing.Point(851, 81)
        Me.Label27.Name = "Label27"
        Me.Label27.Size = New System.Drawing.Size(32, 529)
        Me.Label27.TabIndex = 134
        Me.Label27.Text = "1" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "2" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "3" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "4" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "5" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "6" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "7" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "8" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "9" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "10" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "11" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "12" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "13" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "14" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "15" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "16" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "17" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "18" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "19" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "20" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "21" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "22" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "23" &
    "" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "24" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "25"
        Me.Label27.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label32
        '
        Me.Label32.Font = New System.Drawing.Font("Courier New", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label32.ForeColor = System.Drawing.Color.White
        Me.Label32.Location = New System.Drawing.Point(1651, 81)
        Me.Label32.Name = "Label32"
        Me.Label32.Size = New System.Drawing.Size(35, 529)
        Me.Label32.TabIndex = 133
        Me.Label32.Text = "1" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "2" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "3" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "4" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "5" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "6" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "7" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "8" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "9" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "10" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "11" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "12" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "13" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "14" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "15" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "16" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "17" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "18" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "19" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "20" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "21" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "22" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "23" &
    "" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "24" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "25" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10)
        Me.Label32.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label31
        '
        Me.Label31.Font = New System.Drawing.Font("Courier New", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label31.ForeColor = System.Drawing.Color.White
        Me.Label31.Location = New System.Drawing.Point(1516, 58)
        Me.Label31.Name = "Label31"
        Me.Label31.Size = New System.Drawing.Size(135, 20)
        Me.Label31.TabIndex = 132
        Me.Label31.Text = "SQUAWK"
        Me.Label31.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        '
        'LST7
        '
        Me.LST7.BackColor = System.Drawing.Color.FromArgb(CType(CType(27, Byte), Integer), CType(CType(27, Byte), Integer), CType(CType(27, Byte), Integer))
        Me.LST7.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.LST7.Font = New System.Drawing.Font("Courier New", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LST7.ForeColor = System.Drawing.Color.White
        Me.LST7.FormattingEnabled = True
        Me.LST7.ItemHeight = 21
        Me.LST7.Location = New System.Drawing.Point(1515, 81)
        Me.LST7.Name = "LST7"
        Me.LST7.SelectionMode = System.Windows.Forms.SelectionMode.None
        Me.LST7.Size = New System.Drawing.Size(136, 527)
        Me.LST7.TabIndex = 131
        '
        'Label30
        '
        Me.Label30.Font = New System.Drawing.Font("Courier New", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label30.ForeColor = System.Drawing.Color.White
        Me.Label30.Location = New System.Drawing.Point(1374, 58)
        Me.Label30.Name = "Label30"
        Me.Label30.Size = New System.Drawing.Size(135, 20)
        Me.Label30.TabIndex = 130
        Me.Label30.Text = "CLIMB ALT"
        Me.Label30.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        '
        'LST6
        '
        Me.LST6.BackColor = System.Drawing.Color.FromArgb(CType(CType(27, Byte), Integer), CType(CType(27, Byte), Integer), CType(CType(27, Byte), Integer))
        Me.LST6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.LST6.Font = New System.Drawing.Font("Courier New", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LST6.ForeColor = System.Drawing.Color.White
        Me.LST6.FormattingEnabled = True
        Me.LST6.ItemHeight = 21
        Me.LST6.Location = New System.Drawing.Point(1373, 81)
        Me.LST6.Name = "LST6"
        Me.LST6.SelectionMode = System.Windows.Forms.SelectionMode.None
        Me.LST6.Size = New System.Drawing.Size(136, 527)
        Me.LST6.TabIndex = 129
        '
        'Label29
        '
        Me.Label29.Font = New System.Drawing.Font("Courier New", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label29.ForeColor = System.Drawing.Color.White
        Me.Label29.Location = New System.Drawing.Point(1267, 58)
        Me.Label29.Name = "Label29"
        Me.Label29.Size = New System.Drawing.Size(100, 20)
        Me.Label29.TabIndex = 128
        Me.Label29.Text = "RWY"
        Me.Label29.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        '
        'LST5
        '
        Me.LST5.BackColor = System.Drawing.Color.FromArgb(CType(CType(27, Byte), Integer), CType(CType(27, Byte), Integer), CType(CType(27, Byte), Integer))
        Me.LST5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.LST5.Font = New System.Drawing.Font("Courier New", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LST5.ForeColor = System.Drawing.Color.White
        Me.LST5.FormattingEnabled = True
        Me.LST5.ItemHeight = 21
        Me.LST5.Location = New System.Drawing.Point(1266, 81)
        Me.LST5.Name = "LST5"
        Me.LST5.SelectionMode = System.Windows.Forms.SelectionMode.None
        Me.LST5.Size = New System.Drawing.Size(101, 527)
        Me.LST5.TabIndex = 127
        '
        'Label28
        '
        Me.Label28.Font = New System.Drawing.Font("Courier New", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label28.ForeColor = System.Drawing.Color.White
        Me.Label28.Location = New System.Drawing.Point(885, 58)
        Me.Label28.Name = "Label28"
        Me.Label28.Size = New System.Drawing.Size(375, 20)
        Me.Label28.TabIndex = 126
        Me.Label28.Text = "CLEARED VIA"
        Me.Label28.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        '
        'LST4
        '
        Me.LST4.BackColor = System.Drawing.Color.FromArgb(CType(CType(27, Byte), Integer), CType(CType(27, Byte), Integer), CType(CType(27, Byte), Integer))
        Me.LST4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.LST4.Font = New System.Drawing.Font("Courier New", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LST4.ForeColor = System.Drawing.Color.White
        Me.LST4.FormattingEnabled = True
        Me.LST4.ItemHeight = 21
        Me.LST4.Location = New System.Drawing.Point(884, 81)
        Me.LST4.Name = "LST4"
        Me.LST4.SelectionMode = System.Windows.Forms.SelectionMode.None
        Me.LST4.Size = New System.Drawing.Size(376, 527)
        Me.LST4.TabIndex = 125
        '
        'Label26
        '
        Me.Label26.Font = New System.Drawing.Font("Courier New", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label26.ForeColor = System.Drawing.Color.White
        Me.Label26.Location = New System.Drawing.Point(714, 58)
        Me.Label26.Name = "Label26"
        Me.Label26.Size = New System.Drawing.Size(135, 20)
        Me.Label26.TabIndex = 124
        Me.Label26.Text = "DESTINATION"
        Me.Label26.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        '
        'LST3
        '
        Me.LST3.BackColor = System.Drawing.Color.FromArgb(CType(CType(27, Byte), Integer), CType(CType(27, Byte), Integer), CType(CType(27, Byte), Integer))
        Me.LST3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.LST3.Font = New System.Drawing.Font("Courier New", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LST3.ForeColor = System.Drawing.Color.White
        Me.LST3.FormattingEnabled = True
        Me.LST3.ItemHeight = 21
        Me.LST3.Location = New System.Drawing.Point(713, 81)
        Me.LST3.Name = "LST3"
        Me.LST3.SelectionMode = System.Windows.Forms.SelectionMode.None
        Me.LST3.Size = New System.Drawing.Size(136, 527)
        Me.LST3.TabIndex = 123
        '
        'Label25
        '
        Me.Label25.Font = New System.Drawing.Font("Courier New", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label25.ForeColor = System.Drawing.Color.White
        Me.Label25.Location = New System.Drawing.Point(548, 58)
        Me.Label25.Name = "Label25"
        Me.Label25.Size = New System.Drawing.Size(159, 20)
        Me.Label25.TabIndex = 122
        Me.Label25.Text = "AIRCRAFT TYPE"
        Me.Label25.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        '
        'LST2
        '
        Me.LST2.BackColor = System.Drawing.Color.FromArgb(CType(CType(27, Byte), Integer), CType(CType(27, Byte), Integer), CType(CType(27, Byte), Integer))
        Me.LST2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.LST2.Font = New System.Drawing.Font("Courier New", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LST2.ForeColor = System.Drawing.Color.White
        Me.LST2.FormattingEnabled = True
        Me.LST2.ItemHeight = 21
        Me.LST2.Location = New System.Drawing.Point(547, 81)
        Me.LST2.Name = "LST2"
        Me.LST2.SelectionMode = System.Windows.Forms.SelectionMode.None
        Me.LST2.Size = New System.Drawing.Size(160, 527)
        Me.LST2.TabIndex = 121
        '
        'Label22
        '
        Me.Label22.Font = New System.Drawing.Font("Courier New", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label22.ForeColor = System.Drawing.Color.White
        Me.Label22.Location = New System.Drawing.Point(373, 58)
        Me.Label22.Name = "Label22"
        Me.Label22.Size = New System.Drawing.Size(168, 20)
        Me.Label22.TabIndex = 118
        Me.Label22.Text = "CALLSIGN"
        Me.Label22.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        '
        'LST1
        '
        Me.LST1.BackColor = System.Drawing.Color.FromArgb(CType(CType(27, Byte), Integer), CType(CType(27, Byte), Integer), CType(CType(27, Byte), Integer))
        Me.LST1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.LST1.Font = New System.Drawing.Font("Courier New", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LST1.ForeColor = System.Drawing.Color.White
        Me.LST1.FormattingEnabled = True
        Me.LST1.ItemHeight = 21
        Me.LST1.Location = New System.Drawing.Point(372, 81)
        Me.LST1.Name = "LST1"
        Me.LST1.SelectionMode = System.Windows.Forms.SelectionMode.None
        Me.LST1.Size = New System.Drawing.Size(169, 527)
        Me.LST1.TabIndex = 117
        '
        'Button3
        '
        Me.Button3.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button3.Font = New System.Drawing.Font("Courier New", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button3.ForeColor = System.Drawing.Color.White
        Me.Button3.Location = New System.Drawing.Point(855, 677)
        Me.Button3.Name = "Button3"
        Me.Button3.Size = New System.Drawing.Size(831, 50)
        Me.Button3.TabIndex = 116
        Me.Button3.Text = "REMOVE ALL CLEARANCES"
        Me.Button3.UseVisualStyleBackColor = True
        '
        'L2
        '
        Me.L2.BackColor = System.Drawing.Color.White
        Me.L2.Font = New System.Drawing.Font("Courier New", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.L2.ForeColor = System.Drawing.Color.Black
        Me.L2.Location = New System.Drawing.Point(12, 176)
        Me.L2.Name = "L2"
        Me.L2.Size = New System.Drawing.Size(348, 10)
        Me.L2.TabIndex = 115
        Me.L2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'L1
        '
        Me.L1.BackColor = System.Drawing.Color.White
        Me.L1.Font = New System.Drawing.Font("Courier New", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.L1.ForeColor = System.Drawing.Color.Black
        Me.L1.Location = New System.Drawing.Point(351, 13)
        Me.L1.Name = "L1"
        Me.L1.Size = New System.Drawing.Size(10, 602)
        Me.L1.TabIndex = 114
        Me.L1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'TB11
        '
        Me.TB11.BackColor = System.Drawing.Color.FromArgb(CType(CType(25, Byte), Integer), CType(CType(25, Byte), Integer), CType(CType(25, Byte), Integer))
        Me.TB11.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.TB11.Font = New System.Drawing.Font("Courier New", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TB11.ForeColor = System.Drawing.Color.White
        Me.TB11.Location = New System.Drawing.Point(206, 452)
        Me.TB11.Name = "TB11"
        Me.TB11.Size = New System.Drawing.Size(139, 29)
        Me.TB11.TabIndex = 113
        '
        'Label17
        '
        Me.Label17.Font = New System.Drawing.Font("Courier New", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label17.ForeColor = System.Drawing.Color.White
        Me.Label17.Location = New System.Drawing.Point(14, 452)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(186, 29)
        Me.Label17.TabIndex = 112
        Me.Label17.Text = "CUSTOM DEST"
        Me.Label17.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'TB10
        '
        Me.TB10.BackColor = System.Drawing.Color.FromArgb(CType(CType(25, Byte), Integer), CType(CType(25, Byte), Integer), CType(CType(25, Byte), Integer))
        Me.TB10.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.TB10.Font = New System.Drawing.Font("Courier New", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TB10.ForeColor = System.Drawing.Color.White
        Me.TB10.Location = New System.Drawing.Point(255, 424)
        Me.TB10.Name = "TB10"
        Me.TB10.Size = New System.Drawing.Size(90, 29)
        Me.TB10.TabIndex = 111
        '
        'Label18
        '
        Me.Label18.Font = New System.Drawing.Font("Courier New", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label18.ForeColor = System.Drawing.Color.White
        Me.Label18.Location = New System.Drawing.Point(14, 425)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(186, 27)
        Me.Label18.TabIndex = 110
        Me.Label18.Text = "CUSTOM DEP RWY"
        Me.Label18.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'TB9
        '
        Me.TB9.BackColor = System.Drawing.Color.FromArgb(CType(CType(25, Byte), Integer), CType(CType(25, Byte), Integer), CType(CType(25, Byte), Integer))
        Me.TB9.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.TB9.Font = New System.Drawing.Font("Courier New", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TB9.ForeColor = System.Drawing.Color.White
        Me.TB9.Location = New System.Drawing.Point(157, 396)
        Me.TB9.Name = "TB9"
        Me.TB9.Size = New System.Drawing.Size(188, 29)
        Me.TB9.TabIndex = 108
        '
        'Label15
        '
        Me.Label15.Font = New System.Drawing.Font("Courier New", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label15.ForeColor = System.Drawing.Color.White
        Me.Label15.Location = New System.Drawing.Point(14, 397)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(202, 28)
        Me.Label15.TabIndex = 107
        Me.Label15.Text = "CUSTOM DEP"
        Me.Label15.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'L4
        '
        Me.L4.BackColor = System.Drawing.Color.White
        Me.L4.Font = New System.Drawing.Font("Courier New", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.L4.ForeColor = System.Drawing.Color.Black
        Me.L4.Location = New System.Drawing.Point(13, 383)
        Me.L4.Name = "L4"
        Me.L4.Size = New System.Drawing.Size(348, 10)
        Me.L4.TabIndex = 106
        Me.L4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'L3
        '
        Me.L3.BackColor = System.Drawing.Color.White
        Me.L3.Font = New System.Drawing.Font("Courier New", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.L3.ForeColor = System.Drawing.Color.Black
        Me.L3.Location = New System.Drawing.Point(13, 312)
        Me.L3.Name = "L3"
        Me.L3.Size = New System.Drawing.Size(348, 10)
        Me.L3.TabIndex = 105
        Me.L3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'CB2
        '
        Me.CB2.AutoSize = True
        Me.CB2.Font = New System.Drawing.Font("Courier New", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CB2.ForeColor = System.Drawing.Color.White
        Me.CB2.Location = New System.Drawing.Point(246, 326)
        Me.CB2.Name = "CB2"
        Me.CB2.Size = New System.Drawing.Size(62, 25)
        Me.CB2.TabIndex = 100
        Me.CB2.Text = "SID"
        Me.CB2.TextAlign = System.Drawing.ContentAlignment.BottomLeft
        Me.CB2.UseVisualStyleBackColor = True
        '
        'CB1
        '
        Me.CB1.AutoSize = True
        Me.CB1.Font = New System.Drawing.Font("Courier New", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CB1.ForeColor = System.Drawing.Color.White
        Me.CB1.Location = New System.Drawing.Point(47, 326)
        Me.CB1.Name = "CB1"
        Me.CB1.Size = New System.Drawing.Size(172, 25)
        Me.CB1.TabIndex = 99
        Me.CB1.Text = "VECTOR/CUSTOM"
        Me.CB1.TextAlign = System.Drawing.ContentAlignment.BottomLeft
        Me.CB1.UseVisualStyleBackColor = True
        '
        'Label12
        '
        Me.Label12.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Label12.Font = New System.Drawing.Font("Courier New", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label12.ForeColor = System.Drawing.Color.Black
        Me.Label12.Location = New System.Drawing.Point(13, 325)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(332, 27)
        Me.Label12.TabIndex = 104
        Me.Label12.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'TB7
        '
        Me.TB7.BackColor = System.Drawing.Color.FromArgb(CType(CType(25, Byte), Integer), CType(CType(25, Byte), Integer), CType(CType(25, Byte), Integer))
        Me.TB7.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.TB7.Font = New System.Drawing.Font("Courier New", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TB7.ForeColor = System.Drawing.Color.White
        Me.TB7.Location = New System.Drawing.Point(225, 351)
        Me.TB7.Name = "TB7"
        Me.TB7.Size = New System.Drawing.Size(120, 29)
        Me.TB7.TabIndex = 103
        Me.TB7.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label20
        '
        Me.Label20.Font = New System.Drawing.Font("Courier New", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label20.ForeColor = System.Drawing.Color.White
        Me.Label20.Location = New System.Drawing.Point(14, 352)
        Me.Label20.Name = "Label20"
        Me.Label20.Size = New System.Drawing.Size(186, 27)
        Me.Label20.TabIndex = 102
        Me.Label20.Text = "SQUAWK CODE"
        Me.Label20.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label10
        '
        Me.Label10.Font = New System.Drawing.Font("Courier New", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label10.ForeColor = System.Drawing.Color.White
        Me.Label10.Location = New System.Drawing.Point(14, 281)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(186, 27)
        Me.Label10.TabIndex = 98
        Me.Label10.Text = "DESTINATION"
        Me.Label10.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'TB6
        '
        Me.TB6.BackColor = System.Drawing.Color.FromArgb(CType(CType(25, Byte), Integer), CType(CType(25, Byte), Integer), CType(CType(25, Byte), Integer))
        Me.TB6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.TB6.Font = New System.Drawing.Font("Courier New", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TB6.ForeColor = System.Drawing.Color.White
        Me.TB6.Location = New System.Drawing.Point(225, 280)
        Me.TB6.Name = "TB6"
        Me.TB6.Size = New System.Drawing.Size(120, 29)
        Me.TB6.TabIndex = 97
        '
        'Label9
        '
        Me.Label9.Font = New System.Drawing.Font("Courier New", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label9.ForeColor = System.Drawing.Color.White
        Me.Label9.Location = New System.Drawing.Point(14, 253)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(186, 28)
        Me.Label9.TabIndex = 96
        Me.Label9.Text = "AIRCRAFT TYPE"
        Me.Label9.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'TB5
        '
        Me.TB5.BackColor = System.Drawing.Color.FromArgb(CType(CType(25, Byte), Integer), CType(CType(25, Byte), Integer), CType(CType(25, Byte), Integer))
        Me.TB5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.TB5.Font = New System.Drawing.Font("Courier New", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TB5.ForeColor = System.Drawing.Color.White
        Me.TB5.Location = New System.Drawing.Point(246, 252)
        Me.TB5.Name = "TB5"
        Me.TB5.Size = New System.Drawing.Size(99, 29)
        Me.TB5.TabIndex = 95
        '
        'Label8
        '
        Me.Label8.Font = New System.Drawing.Font("Courier New", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label8.ForeColor = System.Drawing.Color.White
        Me.Label8.Location = New System.Drawing.Point(14, 225)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(167, 28)
        Me.Label8.TabIndex = 94
        Me.Label8.Text = "CALLSIGN"
        Me.Label8.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'TB4
        '
        Me.TB4.BackColor = System.Drawing.Color.FromArgb(CType(CType(25, Byte), Integer), CType(CType(25, Byte), Integer), CType(CType(25, Byte), Integer))
        Me.TB4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.TB4.Font = New System.Drawing.Font("Courier New", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TB4.ForeColor = System.Drawing.Color.White
        Me.TB4.Location = New System.Drawing.Point(187, 224)
        Me.TB4.Name = "TB4"
        Me.TB4.Size = New System.Drawing.Size(158, 29)
        Me.TB4.TabIndex = 93
        '
        'Label6
        '
        Me.Label6.Font = New System.Drawing.Font("Courier New", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.ForeColor = System.Drawing.Color.White
        Me.Label6.Location = New System.Drawing.Point(13, 190)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(332, 34)
        Me.Label6.TabIndex = 92
        Me.Label6.Text = "CLEARANCE GENERATOR"
        Me.Label6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Button2
        '
        Me.Button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button2.Font = New System.Drawing.Font("Courier New", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button2.ForeColor = System.Drawing.Color.White
        Me.Button2.Location = New System.Drawing.Point(13, 515)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(332, 100)
        Me.Button2.TabIndex = 90
        Me.Button2.Text = "EXECUTE AND ADD"
        Me.Button2.UseVisualStyleBackColor = True
        '
        'Label7
        '
        Me.Label7.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Label7.Font = New System.Drawing.Font("Courier New", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.ForeColor = System.Drawing.Color.Black
        Me.Label7.Location = New System.Drawing.Point(13, 224)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(332, 85)
        Me.Label7.TabIndex = 91
        Me.Label7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label5
        '
        Me.Label5.Font = New System.Drawing.Font("Courier New", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.ForeColor = System.Drawing.Color.White
        Me.Label5.Location = New System.Drawing.Point(14, 104)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(186, 27)
        Me.Label5.TabIndex = 89
        Me.Label5.Text = "STANDARD CLIMB"
        Me.Label5.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'TB3
        '
        Me.TB3.BackColor = System.Drawing.Color.FromArgb(CType(CType(25, Byte), Integer), CType(CType(25, Byte), Integer), CType(CType(25, Byte), Integer))
        Me.TB3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.TB3.Font = New System.Drawing.Font("Courier New", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TB3.ForeColor = System.Drawing.Color.White
        Me.TB3.Location = New System.Drawing.Point(206, 103)
        Me.TB3.Name = "TB3"
        Me.TB3.Size = New System.Drawing.Size(139, 29)
        Me.TB3.TabIndex = 88
        '
        'Label4
        '
        Me.Label4.Font = New System.Drawing.Font("Courier New", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.ForeColor = System.Drawing.Color.White
        Me.Label4.Location = New System.Drawing.Point(14, 76)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(186, 28)
        Me.Label4.TabIndex = 87
        Me.Label4.Text = "DEPARTURE RUNWAY"
        Me.Label4.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'TB2
        '
        Me.TB2.BackColor = System.Drawing.Color.FromArgb(CType(CType(25, Byte), Integer), CType(CType(25, Byte), Integer), CType(CType(25, Byte), Integer))
        Me.TB2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.TB2.Font = New System.Drawing.Font("Courier New", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TB2.ForeColor = System.Drawing.Color.White
        Me.TB2.Location = New System.Drawing.Point(239, 75)
        Me.TB2.Name = "TB2"
        Me.TB2.Size = New System.Drawing.Size(106, 29)
        Me.TB2.TabIndex = 86
        '
        'Label3
        '
        Me.Label3.Font = New System.Drawing.Font("Courier New", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.ForeColor = System.Drawing.Color.White
        Me.Label3.Location = New System.Drawing.Point(14, 48)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(186, 28)
        Me.Label3.TabIndex = 85
        Me.Label3.Text = "AIRPORT CODE"
        Me.Label3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label1
        '
        Me.Label1.Font = New System.Drawing.Font("Courier New", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.Color.White
        Me.Label1.Location = New System.Drawing.Point(13, 13)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(332, 34)
        Me.Label1.TabIndex = 84
        Me.Label1.Text = "AIRPORT SETUP"
        Me.Label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'TB1
        '
        Me.TB1.BackColor = System.Drawing.Color.FromArgb(CType(CType(25, Byte), Integer), CType(CType(25, Byte), Integer), CType(CType(25, Byte), Integer))
        Me.TB1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.TB1.Font = New System.Drawing.Font("Courier New", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TB1.ForeColor = System.Drawing.Color.White
        Me.TB1.Location = New System.Drawing.Point(206, 47)
        Me.TB1.Name = "TB1"
        Me.TB1.Size = New System.Drawing.Size(139, 29)
        Me.TB1.TabIndex = 82
        '
        'Button1
        '
        Me.Button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button1.Font = New System.Drawing.Font("Courier New", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button1.ForeColor = System.Drawing.Color.White
        Me.Button1.Location = New System.Drawing.Point(13, 135)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(332, 37)
        Me.Button1.TabIndex = 81
        Me.Button1.Text = "SET UP"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'Label2
        '
        Me.Label2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Label2.Font = New System.Drawing.Font("Courier New", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.ForeColor = System.Drawing.Color.Black
        Me.Label2.Location = New System.Drawing.Point(13, 47)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(332, 85)
        Me.Label2.TabIndex = 83
        Me.Label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label11
        '
        Me.Label11.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Label11.Font = New System.Drawing.Font("Courier New", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label11.ForeColor = System.Drawing.Color.Black
        Me.Label11.Location = New System.Drawing.Point(13, 325)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(332, 55)
        Me.Label11.TabIndex = 101
        Me.Label11.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label16
        '
        Me.Label16.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Label16.Font = New System.Drawing.Font("Courier New", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label16.ForeColor = System.Drawing.Color.Black
        Me.Label16.Location = New System.Drawing.Point(13, 396)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(332, 113)
        Me.Label16.TabIndex = 109
        Me.Label16.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label23
        '
        Me.Label23.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Label23.Font = New System.Drawing.Font("Courier New", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label23.ForeColor = System.Drawing.Color.Black
        Me.Label23.Location = New System.Drawing.Point(367, 47)
        Me.Label23.Name = "Label23"
        Me.Label23.Size = New System.Drawing.Size(1320, 568)
        Me.Label23.TabIndex = 119
        Me.Label23.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label24
        '
        Me.Label24.Font = New System.Drawing.Font("Courier New", 21.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label24.ForeColor = System.Drawing.Color.White
        Me.Label24.Location = New System.Drawing.Point(367, 10)
        Me.Label24.Name = "Label24"
        Me.Label24.Size = New System.Drawing.Size(1319, 34)
        Me.Label24.TabIndex = 120
        Me.Label24.Text = "CLEARANCES"
        Me.Label24.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Main
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.FromArgb(CType(CType(25, Byte), Integer), CType(CType(25, Byte), Integer), CType(CType(25, Byte), Integer))
        Me.ClientSize = New System.Drawing.Size(1698, 778)
        Me.Controls.Add(Me.C1)
        Me.Controls.Add(Me.Label13)
        Me.Controls.Add(Me.TB12)
        Me.Controls.Add(Me.Label33)
        Me.Controls.Add(Me.Button9)
        Me.Controls.Add(Me.Button7)
        Me.Controls.Add(Me.Button5)
        Me.Controls.Add(Me.Button8)
        Me.Controls.Add(Me.Button6)
        Me.Controls.Add(Me.Button4)
        Me.Controls.Add(Me.Label27)
        Me.Controls.Add(Me.Label32)
        Me.Controls.Add(Me.Label31)
        Me.Controls.Add(Me.LST7)
        Me.Controls.Add(Me.Label30)
        Me.Controls.Add(Me.LST6)
        Me.Controls.Add(Me.Label29)
        Me.Controls.Add(Me.LST5)
        Me.Controls.Add(Me.Label28)
        Me.Controls.Add(Me.LST4)
        Me.Controls.Add(Me.Label26)
        Me.Controls.Add(Me.LST3)
        Me.Controls.Add(Me.Label25)
        Me.Controls.Add(Me.LST2)
        Me.Controls.Add(Me.Label22)
        Me.Controls.Add(Me.LST1)
        Me.Controls.Add(Me.Button3)
        Me.Controls.Add(Me.L2)
        Me.Controls.Add(Me.L1)
        Me.Controls.Add(Me.TB11)
        Me.Controls.Add(Me.Label17)
        Me.Controls.Add(Me.TB10)
        Me.Controls.Add(Me.Label18)
        Me.Controls.Add(Me.TB9)
        Me.Controls.Add(Me.Label15)
        Me.Controls.Add(Me.L4)
        Me.Controls.Add(Me.L3)
        Me.Controls.Add(Me.CB2)
        Me.Controls.Add(Me.CB1)
        Me.Controls.Add(Me.Label12)
        Me.Controls.Add(Me.TB7)
        Me.Controls.Add(Me.Label20)
        Me.Controls.Add(Me.Label10)
        Me.Controls.Add(Me.TB6)
        Me.Controls.Add(Me.Label9)
        Me.Controls.Add(Me.TB5)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.TB4)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.Button2)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.TB3)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.TB2)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.TB1)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label11)
        Me.Controls.Add(Me.Label16)
        Me.Controls.Add(Me.Label23)
        Me.Controls.Add(Me.Label24)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MaximizeBox = False
        Me.Name = "Main"
        Me.Text = "Dan's ATC24 Clearance Generator Version 3.0.6"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents C1 As ComboBox
    Friend WithEvents Label13 As Label
    Friend WithEvents TB12 As TextBox
    Friend WithEvents Label33 As Label
    Friend WithEvents Button9 As Button
    Friend WithEvents Button7 As Button
    Friend WithEvents Button5 As Button
    Friend WithEvents Button8 As Button
    Friend WithEvents Button6 As Button
    Friend WithEvents Button4 As Button
    Friend WithEvents Label27 As Label
    Friend WithEvents Label32 As Label
    Friend WithEvents Label31 As Label
    Friend WithEvents LST7 As ListBox
    Friend WithEvents Label30 As Label
    Friend WithEvents LST6 As ListBox
    Friend WithEvents Label29 As Label
    Friend WithEvents LST5 As ListBox
    Friend WithEvents Label28 As Label
    Friend WithEvents LST4 As ListBox
    Friend WithEvents Label26 As Label
    Friend WithEvents LST3 As ListBox
    Friend WithEvents Label25 As Label
    Friend WithEvents LST2 As ListBox
    Friend WithEvents Label22 As Label
    Friend WithEvents LST1 As ListBox
    Friend WithEvents Button3 As Button
    Friend WithEvents L2 As Label
    Friend WithEvents L1 As Label
    Friend WithEvents TB11 As TextBox
    Friend WithEvents Label17 As Label
    Friend WithEvents TB10 As TextBox
    Friend WithEvents Label18 As Label
    Friend WithEvents TB9 As TextBox
    Friend WithEvents Label15 As Label
    Friend WithEvents L4 As Label
    Friend WithEvents L3 As Label
    Friend WithEvents CB2 As CheckBox
    Friend WithEvents CB1 As CheckBox
    Friend WithEvents Label12 As Label
    Friend WithEvents TB7 As TextBox
    Friend WithEvents Label20 As Label
    Friend WithEvents Label10 As Label
    Friend WithEvents TB6 As TextBox
    Friend WithEvents Label9 As Label
    Friend WithEvents TB5 As TextBox
    Friend WithEvents Label8 As Label
    Friend WithEvents TB4 As TextBox
    Friend WithEvents Label6 As Label
    Friend WithEvents Button2 As Button
    Friend WithEvents Label7 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents TB3 As TextBox
    Friend WithEvents Label4 As Label
    Friend WithEvents TB2 As TextBox
    Friend WithEvents Label3 As Label
    Friend WithEvents Label1 As Label
    Friend WithEvents TB1 As TextBox
    Friend WithEvents Button1 As Button
    Friend WithEvents Label2 As Label
    Friend WithEvents Label11 As Label
    Friend WithEvents Label16 As Label
    Friend WithEvents Label23 As Label
    Friend WithEvents Label24 As Label
End Class
